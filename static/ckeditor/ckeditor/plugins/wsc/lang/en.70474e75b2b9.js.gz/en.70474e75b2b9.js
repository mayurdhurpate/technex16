﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'en', {
	btnIgnore: 'Ignore',
	btnIgnoreAll: 'Ignore All',
	btnReplace: 'Replace',
	btnReplaceAll: 'Replace All',
	btnUndo: 'Undo',
	changeTo: 'Change to',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Spell checker not installed. Do you want to download it now?',
	manyChanges: 'Spell check complete: %1 words changed',
	noChanges: 'Spell check complete: No words changed',
	noMispell: 'Spell check complete: No misspellings found',
	noSuggestions: '- No suggestions -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Not in dictionary',
	oneChange: 'Spell check complete: One word changed',
	progress: 'Spell check in progress...',
	title: 'Spell Checker',
	toolbar: 'Check Spelling'
});
