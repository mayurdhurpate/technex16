﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uploadwidget","ku",{abort:"بارکردنەکە بڕدرا لەلایەن بەکارهێنەر.",doneOne:"پەڕگەکە بەسەرکەوتووانە بارکرا.",doneMany:"بەسەرکەوتووانە بارکرا %1 پەڕگە.",uploadOne:"پەڕگە باردەکرێت ({percentage}%)...",uploadMany:"پەڕگە باردەکرێت, {current} لە {max} ئەنجامدراوە ({percentage}%)..."});