﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'sr-latn', {
	btnIgnore: 'Ignoriši',
	btnIgnoreAll: 'Ignoriši sve',
	btnReplace: 'Zameni',
	btnReplaceAll: 'Zameni sve',
	btnUndo: 'Vrati akciju',
	changeTo: 'Izmeni',
	errorLoading: 'Error loading application service host: %s.',
	ieSpellDownload: 'Provera spelovanja nije instalirana. Da li želite da je skinete sa Interneta?',
	manyChanges: 'Provera spelovanja završena: %1 reč(i) je izmenjeno',
	noChanges: 'Provera spelovanja završena: Nije izmenjena nijedna rec',
	noMispell: 'Provera spelovanja završena: greške nisu pronadene',
	noSuggestions: '- Bez sugestija -',
	notAvailable: 'Sorry, but service is unavailable now.',
	notInDic: 'Nije u rečniku',
	oneChange: 'Provera spelovanja završena: Izmenjena je jedna reč',
	progress: 'Provera spelovanja u toku...',
	title: 'Spell Checker',
	toolbar: 'Proveri spelovanje'
});
