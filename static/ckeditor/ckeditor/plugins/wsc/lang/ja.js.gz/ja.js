﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'ja', {
	btnIgnore: '無視',
	btnIgnoreAll: 'すべて無視',
	btnReplace: '置換',
	btnReplaceAll: 'すべて置換',
	btnUndo: 'やり直し',
	changeTo: '変更',
	errorLoading: 'アプリケーションサービスホスト読込みエラー: %s.',
	ieSpellDownload: 'スペルチェッカーがインストールされていません。今すぐダウンロードしますか?',
	manyChanges: 'スペルチェック完了: %1 語句変更されました',
	noChanges: 'スペルチェック完了: 語句は変更されませんでした',
	noMispell: 'スペルチェック完了: スペルの誤りはありませんでした',
	noSuggestions: '- 該当なし -',
	notAvailable: '申し訳ありません、現在サービスを利用することができません',
	notInDic: '辞書にありません',
	oneChange: 'スペルチェック完了: １語句変更されました',
	progress: 'スペルチェック処理中...',
	title: 'スペルチェック',
	toolbar: 'スペルチェック'
});
