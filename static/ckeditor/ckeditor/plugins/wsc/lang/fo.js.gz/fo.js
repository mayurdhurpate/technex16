﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'fo', {
	btnIgnore: 'Forfjóna',
	btnIgnoreAll: 'Forfjóna alt',
	btnReplace: 'Yvirskriva',
	btnReplaceAll: 'Yvirskriva alt',
	btnUndo: 'Angra',
	changeTo: 'Broyt til',
	errorLoading: 'Feilur við innlesing av application service host: %s.',
	ieSpellDownload: 'Rættstavarin er ikki tøkur í tekstviðgeranum. Vilt tú heinta hann nú?',
	manyChanges: 'Rættstavarin liðugur: %1 orð broytt',
	noChanges: 'Rættstavarin liðugur: Einki orð varð broytt',
	noMispell: 'Rættstavarin liðugur: Eingin feilur funnin',
	noSuggestions: '- Einki uppskot -',
	notAvailable: 'Tíverri, ikki tøkt í løtuni.',
	notInDic: 'Finst ikki í orðabókini',
	oneChange: 'Rættstavarin liðugur: Eitt orð er broytt',
	progress: 'Rættstavarin arbeiðir...',
	title: 'Kanna stavseting',
	toolbar: 'Kanna stavseting'
});
