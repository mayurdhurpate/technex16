﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("placeholder","eo",{title:"Atributoj de la rezervita spaco",toolbar:"Rezervita Spaco",name:"Nomo de la rezervita spaco",invalidName:"La rezervita spaco ne povas esti malplena kaj ne povas enteni la sekvajn signojn : [, ], <, >",pathName:"rezervita spaco"});