﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'da', {
	btnIgnore: 'Ignorér',
	btnIgnoreAll: 'Ignorér alle',
	btnReplace: 'Erstat',
	btnReplaceAll: 'Erstat alle',
	btnUndo: 'Tilbage',
	changeTo: 'Forslag',
	errorLoading: 'Fejl ved indlæsning af host: %s.',
	ieSpellDownload: 'Stavekontrol ikke installeret. Vil du installere den nu?',
	manyChanges: 'Stavekontrol færdig: %1 ord ændret',
	noChanges: 'Stavekontrol færdig: Ingen ord ændret',
	noMispell: 'Stavekontrol færdig: Ingen fejl fundet',
	noSuggestions: '(ingen forslag)',
	notAvailable: 'Stavekontrol er desværre ikke tilgængelig.',
	notInDic: 'Ikke i ordbogen',
	oneChange: 'Stavekontrol færdig: Et ord ændret',
	progress: 'Stavekontrollen arbejder...',
	title: 'Stavekontrol',
	toolbar: 'Stavekontrol'
});
