﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'uk', {
	btnIgnore: 'Пропустити',
	btnIgnoreAll: 'Пропустити все',
	btnReplace: 'Замінити',
	btnReplaceAll: 'Замінити все',
	btnUndo: 'Назад',
	changeTo: 'Замінити на',
	errorLoading: 'Помилка завантаження : %s.',
	ieSpellDownload: 'Модуль перевірки орфографії не встановлено. Бажаєте завантажити його зараз?',
	manyChanges: 'Перевірку орфографії завершено: 1% слів(ова) змінено',
	noChanges: 'Перевірку орфографії завершено: жодне слово не змінено',
	noMispell: 'Перевірку орфографії завершено: помилок не знайдено',
	noSuggestions: '- немає варіантів -',
	notAvailable: 'Вибачте, але сервіс наразі недоступний.',
	notInDic: 'Немає в словнику',
	oneChange: 'Перевірку орфографії завершено: змінено одне слово',
	progress: 'Виконується перевірка орфографії...',
	title: 'Перевірка орфографії',
	toolbar: 'Перевірити орфографію'
});
