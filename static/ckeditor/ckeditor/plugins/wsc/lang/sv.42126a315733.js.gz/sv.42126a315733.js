﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'wsc', 'sv', {
	btnIgnore: 'Ignorera',
	btnIgnoreAll: 'Ignorera alla',
	btnReplace: 'Ersätt',
	btnReplaceAll: 'Ersätt alla',
	btnUndo: 'Ångra',
	changeTo: 'Ändra till',
	errorLoading: 'Tjänsten är ej tillgänglig: %s.',
	ieSpellDownload: 'Stavningskontrollen är ej installerad. Vill du göra det nu?',
	manyChanges: 'Stavningskontroll slutförd: %1 ord rättades.',
	noChanges: 'Stavningskontroll slutförd: Inga ord rättades.',
	noMispell: 'Stavningskontroll slutförd: Inga stavfel påträffades.',
	noSuggestions: '- Förslag saknas -',
	notAvailable: 'Tyvärr är tjänsten ej tillgänglig nu',
	notInDic: 'Saknas i ordlistan',
	oneChange: 'Stavningskontroll slutförd: Ett ord rättades.',
	progress: 'Stavningskontroll pågår...',
	title: 'Kontrollera stavning',
	toolbar: 'Stavningskontroll'
});
